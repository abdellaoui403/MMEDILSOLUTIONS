Hi, nigut10 here. 
Just a few things you should know about this pack. 
So first of all, this isn't a completely custom made pack. Basicly, it's the public version of the private titanium pack wich I made for the TITANS.
But I modified it and removed our (the titans) custom paintings and music discs, because otherwise it would have been too big for Discord. 
cheers.